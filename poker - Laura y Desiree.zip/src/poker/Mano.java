package poker;

public class Mano {

	private Carta[] cartas;
	private String nombreMano;
	private int indice;
	private int numeroCartas;

	public Mano(String nombreMano, int tamanioMano) {
		this.nombreMano = nombreMano;
	}

	//getters y setters
	public Carta[] getCartas() {
		return cartas;
	}

	public void setCartas(Carta[] cartas) {
		this.cartas = cartas;
	}

	public String getNombreMano() {
		return nombreMano;
	}

	public void setNombreMano(String nombreMano) {
		this.nombreMano = nombreMano;
	}

	public int getIndice() {
		return indice;
	}

	public void setIndice(int indice) {
		this.indice = indice;
	}

	public int getNumeroCartas() {
		return numeroCartas;
	}

	public void setNumeroCartas(int numeroCartas) {
		this.numeroCartas = numeroCartas;
	}

	//metodos
	public void cogerCarta(Carta cartaRobada) {
		cogerCarta = 
		
	}

}
