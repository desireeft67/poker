package poker;

public class Strat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Carta[] cartas = new Carta[54];
		String[] valor = {"AsC", "2C", "3C", "4C", "5C", "6C", "7C", "8C", "9C", "JC", "QC", "KC",
							"AsP", "2P", "3P", "4P", "5P", "6P", "7P", "8P", "9P", "JP", "QP", "KP",
							"AsT", "2T", "3T", "4T", "5T", "6T", "7T", "8T", "9T", "JT", "QT", "KT",
							"AsR", "2R", "3R", "4R", "5R", "6R", "7R", "8R", "9R", "JR", "QR", "KR", 
							"Comodín", "Comodín", "Comodín", "Comodín"};
	}

}
